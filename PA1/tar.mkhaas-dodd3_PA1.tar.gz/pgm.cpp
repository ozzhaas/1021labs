/*Kellen Haas
 *Patrick Dodd
 *CPSC 1020
 *Patrick Dodd
 *Assignment 1
 *2/27/20
*/
