/*Kellen Haas
 *Patrick Dodd
 *CPSC 1020
 *Assignment 1
 *2/27/20
*/
#include "grayPixel.h"

GrayPixel::GrayPixel(int w, int h, int max) {


}

GrayPixel GrayPixel::readGrayPixel(ifstream& input) {
    input >> row

}


void GrayPixel::writeGrayPixel(ofstream& output) {
    output <<
}
