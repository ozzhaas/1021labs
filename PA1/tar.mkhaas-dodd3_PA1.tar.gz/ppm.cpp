/*Kellen Haas
 *Patrick Dodd
 *CPSC 1020
 *Assignment 1
 *2/27/20
*/
