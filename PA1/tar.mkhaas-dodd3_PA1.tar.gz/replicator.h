/*Kellen Haas
 *Patrick Dodd
 *CPSC 1020
 *Assignment 1
 *2/27/20
*/

#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include "colorPixel.h"
#include "grayPixel.h"
#include "header.h"

//
// class Replicator {
//
//     private:
//         Header* head;
//         ColorPixel* colorPix;
//         GrayPixel* grayPix;
//
//
//     public:
//         Header head(string, int, int, int);
//         ColorPixel colorPix(unsigned char, unsigned char, unsigned char);
//         GrayPixel grayPix();
//         void replicate(Header, ColorPixel, GrayPixel);
//
// };
