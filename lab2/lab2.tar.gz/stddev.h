#ifndef STDDEV_H
#define STDDEV_H

#include <iostream>
#include <math.h>
#include <stdio.h>

/*This function will take in an array of floating point numbers
and an integer that's value is the number of floating point
numbers in the array. It will then use these two variables
to compute the standard deviation of the numbers in the array.*/

    void stats (float* data, int n);


#endif
