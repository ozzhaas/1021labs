#ifndef STDDEV_H
#define STDDEV_H

#include <iostream>
#include <math.h>
#include <stdio.h>

    void stats (float* data, int n);


#endif
