#include <iostream>
using namespace std;

int main () {

	cout << "This is my first C++ program !\nI love Linux !\n";

	return 0;
}
